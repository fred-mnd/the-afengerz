#ifndef NICK_CONTROLLER_H
#define NICK_CONTROLLER_H

namespace NickController{
    void run();
}

#endif