#ifndef SUPERHERO_CONTROLLER_H
#define SUPERHERO_CONTROLLER_H

namespace SupController{
    void run();
}

#endif