#include <cstdlib>
#include <ctime>
#include "view/headers/gamePage.h"
#include "etc/utils.h"
#include <iostream>

using namespace std;

int main(){
    system(" ");
    srand(time(0));
    GamePage::init();
}