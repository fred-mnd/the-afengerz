#ifndef CHANGE_HERO_PAGE_H
#define CHANGE_HERO_PAGE_H

namespace ChangeHeroPage{
    void show();
}

#endif