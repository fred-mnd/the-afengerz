#ifndef EAT_PAGE_H
#define EAT_PAGE_H

namespace EatPage{
    void show();
}

#endif