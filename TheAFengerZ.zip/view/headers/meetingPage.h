#ifndef MEETING_PAGE_H
#define MEETING_PAGE_H

namespace MeetingPage{
    void show();
}

#endif