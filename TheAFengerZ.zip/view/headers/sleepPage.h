#ifndef SLEEP_PAGE_H
#define SLEEP_PAGE_H

namespace SleepPage{
    void show();
}

#endif