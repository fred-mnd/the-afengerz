#ifndef TRAINING_PAGE_H
#define TRAINING_PAGE_H

namespace TrainingPage{
    void show();
}

#endif