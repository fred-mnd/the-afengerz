#ifndef UPGRADE_PAGE_H
#define UPGRADE_PAGE_H

namespace UpgradePage{
    void show();
}

#endif